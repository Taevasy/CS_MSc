/**
 * @author Administrator
 * @version 1.0
 * @date 2021-05-21 10:09
 */
public class Furniture extends AbstractEntity {

    public Furniture(String name, String description) {
        super(name, description);
    }
}
