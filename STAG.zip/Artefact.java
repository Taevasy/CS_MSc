/**
 * @author Administrator
 * @version 1.0
 * @date 2021-05-21 10:09
 */
public class Artefact extends AbstractEntity {

    public Artefact(String name, String description) {
        super(name, description);
    }
}
