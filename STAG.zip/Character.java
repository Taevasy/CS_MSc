/**
 * @author Administrator
 * @version 1.0
 * @date 2021-05-22 23:05
 */
public class Character extends AbstractEntity {

    public Character(String name, String description) {
        super(name, description);
    }
}
